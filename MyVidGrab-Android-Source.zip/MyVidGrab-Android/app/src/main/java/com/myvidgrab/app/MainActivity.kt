package com.myvidgrab.app

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import java.net.URLDecoder
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var detectedBox: LinearLayout
    private lateinit var status: TextView
    private lateinit var content: LinearLayout
    private val found = linkedSetOf<String>()
    private var privateMode = true
    private var currentPage = "home"

    private val teal = 0xFF20C9B2.toInt()
    private val bg = 0xFF101820.toInt()
    private val panel = 0xFF1B2935.toInt()
    private val white = 0xFFF4F7FA.toInt()
    private val muted = 0xFF9EADB9.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        configureWebView()
        showHome()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(16, 14, 16, 10)
        }
        val header = TextView(this).apply {
            text = "MYVIDGRAB"
            textSize = 21f
            setTextColor(teal)
            letterSpacing = .12f
            setPadding(2, 8, 2, 12)
        }
        outer.addView(header)
        address = EditText(this).apply {
            hint = "Paste a video page or URL"
            setSingleLine(true)
            textSize = 14f
            setTextColor(white)
            setHintTextColor(muted)
            setPadding(14, 4, 14, 4)
            setBackgroundColor(panel)
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO) { openAddress(); true } else false
            }
        }
        outer.addView(address, LinearLayout.LayoutParams(-1, 48))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        controls.addView(actionButton("‹") { if (web.canGoBack()) web.goBack() }, weightParams())
        controls.addView(actionButton("›") { if (web.canGoForward()) web.goForward() }, weightParams())
        controls.addView(actionButton("Go") { openAddress() }, weightParams(1.4f))
        controls.addView(actionButton(if (privateMode) "Private ✓" else "Private") { togglePrivate() }, weightParams(1.7f))
        outer.addView(controls)
        status = TextView(this).apply {
            text = "Private browsing is ON • Downloads are saved on this device"
            textSize = 11f
            setTextColor(muted)
            setPadding(2, 8, 2, 8)
        }
        outer.addView(status)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        outer.addView(content)
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 2)
        }
        listOf("Home", "Browser", "Downloads", "VPN").forEach { label ->
            nav.addView(actionButton(label) {
                when (label) {
                    "Home" -> showHome()
                    "Browser" -> showBrowser()
                    "Downloads" -> showDownloads()
                    "VPN" -> showVpn()
                }
            }, weightParams(1f))
        }
        outer.addView(nav)
        setContentView(outer)
    }

    private fun weightParams(weight: Float = 1f) = LinearLayout.LayoutParams(0, 44, weight).apply {
        setMargins(3, 6, 3, 6)
    }

    private fun actionButton(label: String, click: () -> Unit) = Button(this).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setTextColor(white)
        setBackgroundColor(panel)
        setOnClickListener { click() }
    }

    private fun title(text: String) = TextView(this).apply {
        this.text = text
        textSize = 19f
        setTextColor(white)
        setPadding(0, 12, 0, 8)
    }

    private fun paragraph(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(muted)
        setPadding(0, 4, 0, 10)
    }

    private fun configureWebView() {
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.setSupportMultipleWindows(false)
        web.addJavascriptInterface(VideoBridge(), "MyVidGrab")
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                address.setText(url)
                injectDetector()
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return false
            }
        }
    }

    private fun injectDetector() {
        val js = """
            (function(){
              if(window.__mvgObserver) return;
              window.__mvgObserver=true;
              function scan(){
                try {
                  var els=[].slice.call(document.querySelectorAll('video, video source'));
                  els.forEach(function(e){
                    var u=e.currentSrc||e.src;
                    if(u && /^https?:/i.test(u)) MyVidGrab.found(u, e.getAttribute('type')||'video');
                    if(e.querySelectorAll) [].slice.call(e.querySelectorAll('source')).forEach(function(s){
                      if(s.src) MyVidGrab.found(s.src,s.type||'video');
                    });
                  });
                  [].slice.call(document.querySelectorAll('a[href]')).forEach(function(a){
                    var u=a.href;
                    if(/\.(mp4|webm|ogv|mov)(\?|#|$)/i.test(u)) MyVidGrab.found(u,'video link');
                  });
                } catch(e) {}
              }
              scan();
              new MutationObserver(scan).observe(document.documentElement,{childList:true,subtree:true,attributes:true});
              setInterval(scan,2500);
            })();
        """.trimIndent()
        web.evaluateJavascript(js, null)
    }

    inner class VideoBridge {
        @JavascriptInterface fun found(url: String, type: String) {
            runOnUiThread {
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    if (found.add(url)) refreshDetected()
                }
            }
        }
    }

    private fun openAddress() {
        var url = address.text.toString().trim()
        if (url.isEmpty()) return
        if (!url.contains("://")) {
            url = if (url.contains(".") && !url.contains(" ")) "https://$url"
                  else "https://www.google.com/search?q=" + Uri.encode(url)
        }
        showBrowser()
        web.loadUrl(url)
    }

    private fun showPage(view: View) {
        content.removeAllViews()
        content.addView(view, LinearLayout.LayoutParams(-1, -1))
    }

    private fun showHome() {
        currentPage = "home"
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(title("Save videos for offline viewing"))
        box.addView(paragraph("Open a page in the built-in browser. MyVidGrab looks for standard video elements and direct video links that the page makes available."))
        box.addView(actionButton("Open browser") { showBrowser(); if (web.url == null) web.loadUrl("https://www.google.com") })
        box.addView(title("Detected videos"))
        detectedBox = box
        refreshDetected()
        showPage(box)
    }

    private fun showBrowser() {
        currentPage = "browser"
        if (web.parent != null) (web.parent as ViewGroup).removeView(web)
        showPage(web)
    }

    private fun refreshDetected() {
        if (!::detectedBox.isInitialized || currentPage != "home") return
        // Rebuild the detected section without replacing the browser instance.
        val box = detectedBox
        while (box.childCount > 3) box.removeViewAt(3)
        if (found.isEmpty()) {
            box.addView(paragraph("No standard video links detected yet. Some sites protect or hide their streams, so detection is not guaranteed."))
        } else {
            found.toList().forEachIndexed { index, url ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 8, 0, 8) }
                row.addView(TextView(this).apply {
                    text = "Video ${index + 1}: " + url.take(90)
                    setTextColor(white); textSize = 12f
                })
                row.addView(actionButton("Download this video") { download(url, null, null) })
                box.addView(row)
            }
        }
    }

    private fun download(url: String, userAgent: String?, contentDisposition: String?) {
        try {
            val fileName = URLUtil.guessFileName(url, contentDisposition, null)
                .ifBlank { "myvidgrab_${System.currentTimeMillis()}.mp4" }
            val request = DownloadManager.Request(Uri.parse(url))
                .setTitle(fileName)
                .setDescription("Downloading with MyVidGrab")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "MyVidGrab/$fileName")
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
            if (!userAgent.isNullOrBlank()) request.addRequestHeader("User-Agent", userAgent)
            val cookies = CookieManager.getInstance().getCookie(url)
            if (!cookies.isNullOrBlank()) request.addRequestHeader("Cookie", cookies)
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            Toast.makeText(this, "Download queued: $fileName", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start download: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showDownloads() {
        currentPage = "downloads"
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(title("Downloads"))
        box.addView(paragraph("Downloads are handled by Android Download Manager and appear in your device Downloads folder."))
        box.addView(actionButton("Open device downloads") {
            try { startActivity(android.content.Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) }
            catch (_: Exception) { Toast.makeText(this, "Open the Downloads app on your device.", Toast.LENGTH_SHORT).show() }
        })
        showPage(box)
    }

    private fun showVpn() {
        currentPage = "vpn"
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(title("VPN"))
        box.addView(paragraph("VPN is not connected or included in this build. A real VPN requires a trusted provider, server infrastructure, and an Android VPN service. This screen does not route or disguise your traffic."))
        box.addView(paragraph("Private browsing only limits local browser history and storage; websites, your network operator, and your internet provider may still see connections."))
        showPage(box)
    }

    private fun togglePrivate() {
        privateMode = !privateMode
        if (privateMode) {
            web.clearHistory()
            web.clearCache(true)
            web.clearFormData()
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            found.clear()
            refreshDetected()
            status.text = "Private browsing is ON • local browser data cleared"
        } else {
            status.text = "Private browsing is OFF • browser data may persist during this session"
        }
        // Do not persist browsing history in either mode in this starter build.
        Toast.makeText(this, if (privateMode) "Private mode enabled; local browser data cleared" else "Private mode disabled", Toast.LENGTH_SHORT).show()
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.parent != null && web.canGoBack()) web.goBack()
        else showHome()
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            web.stopLoading()
            web.removeJavascriptInterface("MyVidGrab")
            web.destroy()
        }
        super.onDestroy()
    }
}
