# MyVidGrab for Android

A starter native Android app with:
- Embedded WebView browser
- Basic detection of standard HTML5 video elements and direct MP4/WebM/OGV/MOV links
- Download queue through Android Download Manager
- Local private-session controls
- Downloads shortcut and an honest VPN status screen
- GitHub Actions workflow that builds a debug APK

## Build on GitHub
1. Create a new GitHub repository and upload the contents of this folder.
2. Open **Actions** and run **Build MyVidGrab APK**, or push to `main`.
3. Open the completed workflow run and download the `MyVidGrab-debug-apk` artifact.
4. The artifact contains `app-debug.apk`. On your Android phone, install it after allowing installation from that source.

## Build locally
Requires JDK 17 and Gradle 8.9:
```bash
gradle assembleDebug
```
APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations
- This is an initial functional starter, not a production-grade universal downloader.
- Sites may block WebView, use cross-origin streams, segmented HLS/DASH, DRM, login-gated media, or other protections. The app does not bypass DRM, paywalls, authentication, or site restrictions.
- Detection is limited to standard HTML5 video/source elements and visible direct video links. Some sites will not expose a downloadable URL.
- Downloads use Android Download Manager. Pause/resume controls and in-app progress tracking are not implemented in this starter.
- Private mode clears local WebView history/cache/cookies when enabled, but it is not anonymity. Sites and network providers can still observe network traffic. Downloads remain on the device.
- VPN is intentionally not implemented as a fake feature. A real VPN needs a legitimate VPN provider/server and Android `VpnService` integration.
- Only download content you own or are authorized to save, and follow the website's terms and applicable law.

## Next production steps
Add robust download-state tracking, per-site compatibility handling, a native media extraction strategy where legally permitted, secure app-lock/private vault, and a real VPN provider integration if you have a provider contract/API.
